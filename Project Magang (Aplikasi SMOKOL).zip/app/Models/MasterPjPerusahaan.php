<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MasterPjPerusahaan extends Model
{
    use HasFactory;
    protected $table = 'master_pj_perusahaan';
    public $timestamps = false;
}
